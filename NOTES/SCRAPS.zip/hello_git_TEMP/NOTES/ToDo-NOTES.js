// This is a list of ideas had "mid-stream."
/*

ToDo This is interesting and could be fun/useful : https://api.github.com/emojis
ToDo Maybe see if user can be autheticated through browser console. 

*/