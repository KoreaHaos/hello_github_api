user_input = gets
puts user_input;
