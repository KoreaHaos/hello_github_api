echo "Hello!";
var=$(eval "ruby ../ruby/get_user_choice.rb");
echo $var;

